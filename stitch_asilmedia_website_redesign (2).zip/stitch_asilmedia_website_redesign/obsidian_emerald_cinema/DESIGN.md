---
name: Obsidian Emerald Cinema
colors:
  surface: '#111317'
  surface-dim: '#111317'
  surface-bright: '#37393d'
  surface-container-lowest: '#0c0e11'
  surface-container-low: '#1a1c1f'
  surface-container: '#1e2023'
  surface-container-high: '#282a2d'
  surface-container-highest: '#333538'
  on-surface: '#e2e2e6'
  on-surface-variant: '#bacbbc'
  inverse-surface: '#e2e2e6'
  inverse-on-surface: '#2f3034'
  outline: '#859587'
  outline-variant: '#3c4a3f'
  surface-tint: '#1ce388'
  primary: '#45f99c'
  on-primary: '#00391d'
  primary-container: '#00dc82'
  on-primary-container: '#005b32'
  inverse-primary: '#006d3e'
  secondary: '#4cd7f6'
  on-secondary: '#003640'
  secondary-container: '#03b5d3'
  on-secondary-container: '#00424e'
  tertiary: '#68f5b8'
  on-tertiary: '#003824'
  tertiary-container: '#46d89d'
  on-tertiary-container: '#005a3c'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#59ffa4'
  primary-fixed-dim: '#1ce388'
  on-primary-fixed: '#00210f'
  on-primary-fixed-variant: '#00522d'
  secondary-fixed: '#acedff'
  secondary-fixed-dim: '#4cd7f6'
  on-secondary-fixed: '#001f26'
  on-secondary-fixed-variant: '#004e5c'
  tertiary-fixed: '#6ffbbe'
  tertiary-fixed-dim: '#4edea3'
  on-tertiary-fixed: '#002113'
  on-tertiary-fixed-variant: '#005236'
  background: '#111317'
  on-background: '#e2e2e6'
  surface-variant: '#333538'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 56px
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 30px
    fontWeight: '800'
    lineHeight: 38px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  badge-label:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.04em
  nav-label:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 18px
  caption:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter-xs: 0.25rem
  gutter-sm: 0.5rem
  gutter-md: 1rem
  gutter-lg: 1.5rem
  gutter-xl: 2rem
  sidebar-width: 260px
  sidebar-collapsed: 76px
  poster-aspect-ratio: 2 / 3
  banner-aspect-ratio: 16 / 9
---

## Brand & Style
This design system defines a next-generation cinematic streaming ecosystem tailored for high-performance video delivery. Designed to elevate the digital viewing experience, it reflects an atmosphere that is deeply immersive, high-velocity, and technically refined. 

The aesthetic is anchored in **Cinematic Glassmorphism with Cyberpunk Precision**: an abyss-deep obsidian canvas punctuated by hyper-luminescent emerald and electric cyan neon accents. Surfaces rely on subtle atmospheric gradients, frosted-glass backdrops (`backdrop-blur`), razor-sharp translucent containment strokes, and ambient green edge-glows that simulate theatrical projection lighting. The visual hierarchy commands attention toward rich poster art while maintaining instantaneous glanceability for media metadata, technical stream qualities (4K, 1080p, TAS-IX network acceleration tags), episode counters, and community ratings.

## Colors
The color architecture is built exclusively for native dark-mode cinematic consumption, ensuring zero visual fatigue during prolonged low-light screening while preserving high color fidelity for media artwork.

- **Background & Canvas:**
  - `Surface Void` (`#090B0E`): Foundational page canvas absorbing ambient light.
  - `Surface Obsidian Base` (`#0F141C`): Sidebar, card background base, and bottom navbars.
  - `Surface Elevated Glass` (`#18202F` at 60% opacity with `backdrop-filter: blur(16px)`): Floating headers, modal dialogs, and elevated popovers.
  - `Border Subtle` (`rgba(255, 255, 255, 0.08)`): Ultra-crisp boundaries separating interactive blocks.
  - `Border Highlight` (`rgba(0, 220, 130, 0.25)`): Subtle neon perimeter stroke on hover and focused cards.

- **Accents & Luminescence:**
  - `Primary Glow` (`#00DC82`): Vibrant emerald applied to call-to-action buttons ("Tomosha qilish"), active navigation pills, playback controls, and quality badges.
  - `Secondary Teal` (`#06B6D4`): Dynamic complementary cyan reserved for platform highlights, TAS-IX local traffic badges, audio stream tags, and multi-track indicators.
  - `Tertiary Mint` (`#10B981`): Balanced green for user approval scores, positive status pills, and bookmark states.
  - `Warning / Cinema Gold` (`#F59E0B`): Star ratings, IMDb score badges, and premiere tags.

- **Typography & Icons:**
  - `Text Primary`: `#FFFFFF` (100% luminance).
  - `Text Secondary`: `#94A3B8` (Slate 400, for genre meta, release years, and subtitle credits).
  - `Text Muted`: `#64748B` (Slate 500, for timestamps, footer legals, and inactive states).

## Typography
Plus Jakarta Sans provides high x-height clarity and modern geometric curvature, ensuring ultra-crisp legibility when overlaying dark imagery or high-density video catalogs.

- **Display & Section Titles:** Employs tight negative tracking (`-0.02em`) with weight `800` (ExtraBold) to convey scale, theatrical gravitas, and high tech energy across carousel banners and category rows ("Sizga tavsiya", "Eng Yangilari").
- **Media Title Cards:** Set to `14px` or `15px` with a strict `font-weight: 600` (SemiBold) truncated cleanly to 1 or 2 lines with an ellipsis to prevent UI height misalignment across movie grids.
- **Micro-Badging:** Technical specs (`4K`, `1080p`, `TAS-IX`, `DUB`) use `badge-label` with uppercase styling, condensed vertical alignment, and slight positive tracking to ensure instant identification at miniature scales.

## Layout & Spacing
The layout implements an asymmetric dashboard-cinema model featuring a persistent vertical left-hand navigation dock coupled with a fluid, multi-tier horizontal media viewport.

- **Structural Grid System:**
  - **Desktop (>= 1280px):** Fixed 260px frosted sidebar; primary content area expands dynamically across a 12-column layout with 16px horizontal gutters and 32px vertical tier spacing. Media rail displays 5–7 cards per viewport with continuous momentum scroll or snap pagination.
  - **Tablet (768px - 1279px):** Sidebar collapses into a slim 76px icon rail; catalog grids transition into 3–4 poster columns with 12px gutters.
  - **Mobile (< 768px):** Sidebar is replaced by a bottom glass dock; top bar handles omni-search; catalog cards scale to a 2-column or 2.5-card horizontal peek slider.
- **Rhythm & Safe Areas:**
  - Poster cards strictly follow a `2:3` golden cinema ratio (`width:height`) to preserve vertical theatrical posters without edge cropping.
  - Hero spotlight banners leverage `16:9` or `21:9` wide theatrical proportions with directional left-to-right and bottom-to-top obsidian linear gradients.

## Elevation & Depth
Elevation is generated through translucent glassmorphism, luminous perimeter strokes, and colored back-glows rather than traditional dark drop shadows.

- **Level 0 (Canvas):** Pure `#090B0E` void tone.
- **Level 1 (Card Rest):** Background of `#0F141C` with an inner fill of `rgba(24, 32, 47, 0.4)` and a 1px border of `rgba(255, 255, 255, 0.06)`.
- **Level 2 (Interactive Floating / Hover):** Poster scales up `1.04x` with cubic-bezier `cubic-bezier(0.2, 0.8, 0.2, 1)`. Surface receives a 1px border of `rgba(0, 220, 130, 0.4)` accompanied by an ambient bloom: `box-shadow: 0 12px 32px -8px rgba(0, 0, 0, 0.8), 0 0 20px -4px rgba(0, 220, 130, 0.25)`.
- **Level 3 (Modals, Cinema Floating Bars & Players):** Frosted glass panels using `rgba(15, 20, 28, 0.75)` with `backdrop-filter: blur(24px)`, crisp highlight line `rgba(255, 255, 255, 0.12)`, and deep atmospheric perimeter shadow `0 24px 48px -12px rgba(0, 0, 0, 0.9)`.

## Shapes
The shape language combines smooth modern curves with high-tech discipline:

- **Poster Cards & Media Modules:** Formed with `rounded-md` (`0.5rem` / `8px` to `12px`) corners to present posters cleanly without cutting into critical art and typographic badges.
- **Interactive Action Buttons & Video Badges:** Utilize `0.5rem` (8px) for buttons and inputs.
- **Genre Selectors & Quality Badges:** Retain a full pill shape (`rounded-full` / `9999px`) to create an ergonomic, tactile contrast against rectangular cinema posters.

## Components

### 1. Movie Poster Card
- **Structure:** `2:3` ratio container with `overflow-hidden`, styled with a continuous 1px border (`rgba(255, 255, 255, 0.08)`).
- **Top Badge Layer:** 
  - Top-left: Stacked or clustered video quality badge (`1080p`, `720p`, `4K`) using a glowing green fill (`#00DC82`) with deep black micro-text (`#000000`, weight 800).
  - Top-right: Community score chip (`+1168`, `★ 8.4`) in translucent black glass (`rgba(9, 11, 14, 0.75)`) featuring a bright green glow star/icon.
- **Bottom Overlay Layer:** Frosted lower banner with episode/series indicator (e.g., `4-fasl 1-qism!`) on a translucent cyan/emerald gradient bar.
- **Footer Meta:** Card title positioned directly beneath art in `body-md` bold white, accompanied by secondary sub-row showing `Tarjima Kinolar` or `Seriallar` and release year in muted slate.

### 2. Fast-Access & TAS-IX Indicators
- Specially targeted badge with an electric cyan border (`#06B6D4`) and pulse dot indicating instantaneous unmetered Uzbek network streaming (`TAS-IX`).

### 3. Primary & Glass Buttons
- **Hero Primary Action ("Tomosha qilish"):** Background `#00DC82`, text `#090B0E` (bold), featuring a subtle neon drop shadow `0 4px 18px rgba(0, 220, 130, 0.45)`. On hover, shifts to `#10B981` with expanded aura.
- **Secondary Glass Button ("Treyler"):** Frosted obsidian surface `rgba(255, 255, 255, 0.08)` with border `rgba(255, 255, 255, 0.15)`, text `#FFFFFF`, and interactive brightness boost.

### 4. Search & Filter Bar
- Full-width pill or `rounded-lg` search input framed in `rgba(24, 32, 47, 0.8)` with an inner cyan focus ring (`#06B6D4`). Prefix icon in emerald; placeholder text reads *"Qidiruv uchun yozing, masalan Flash..."*.

### 5. Genre Filter Chips
- Capsule-shaped pills containing an icon + Uzbek genre text (`Jangari`, `Komediya`, `Fantastika`). Active state fills with emerald-to-teal gradient stroke and subtle glowing backdrop. Inactive state rests on deep obsidian `#18202F` with muted text.

### 6. Sidebar Navigation Dock
- Vertical container with brand insignia at top (emerald forward-play mark + bold title). Navigation items display a left 3px indicator line on active state, colored `#00DC82`, accompanied by soft glowing icon highlights.